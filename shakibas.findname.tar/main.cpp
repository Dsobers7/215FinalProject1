#include <stdio.h>
#include <iostream>
#include <string>
#include <stdlib.h>
using namespace std;

int main (int argc, char* argv[]) {
	if(argc == 2){
		char cmd[1000];
		sprintf(cmd, "./findName.sh %s", argv[1]);
		system(cmd);
	} else {
		printf("Use only 1 argument [studentID]\n");
	}
}
