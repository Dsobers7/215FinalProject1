#!/bin/sh
if [ $# -eq 1 ]; then
	STUDENTNAME=$1
	STUDENTFILES=CSCE215-801M
else
	echo "usage: 'basename $0' [studentname]. Use 1 arguement"
	exit 1
fi

if grep $STUDENTNAME -cqw < $STUDENTFILES ; then
	grep -w $STUDENTNAME < $STUDENTFILES | cut -d ' ' -f 1-2
else
	echo "Sorry that person is not in CSCE215-801M."
	exit 1
fi
